@component('mail::message')
# Dear {{$first_name}} {{$last_name}},

Warm Welcome to our great and exlusive gym & lifestyle center. Your Membership ID is {{$member_id}}

@component('mail::button', ['url' => 'https://greatlifefitness.ng'])
Go back to the site
@endcomponent

Thanks,<br>
{{ config('app.name') }} Team.
@endcomponent
