@component('mail::message')
# Dear {{$full_name}},

Warm Welcome to our great and exlusive Spa center. Your Spa Membership ID is {{$spa_id}} and your booking date is {{$date}}.
 <br><br>Please be puntual and if you wont be able to make it, do let us know.

@component('mail::button', ['url' => 'https://greatlifefitness.ng'])
Go back to the site
@endcomponent

Thanks,<br>
{{ config('app.name') }} Team.
@endcomponent
