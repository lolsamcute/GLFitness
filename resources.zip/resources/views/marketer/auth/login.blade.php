@extends('marketer.layout.auth')

@section('content')


<div class="signupform">
	<div class="container">
		<!-- main content -->
		<!---728x90--->

		<div class="agile_info">
			<div class="w3l_form">
				<div class="left_grid_info">
					<h1>Manage Your Customer Account</h1>
					<p>Login to your portal to Anaylse, Check Report and Manage your Customer</p>
					<img src="{{url ('Lifestyle and Fitness.png') }}" alt="{{url ('Lifestyle and Fitness.png') }}" />
				</div>
			</div>

			<div class="w3_info">
			<!---728x90--->

				<h2>Login to your Account</h2>
				<p>Enter your details to login.</p>
				<form method="POST" action="{{ url('/marketer/login') }}">
                    @csrf

					<label>Email Address</label>
					<div class="input-group @error('email') is-invalid @enderror">
						<span class="fa fa-envelope" aria-hidden="true"></span>
                        <input id="email" type="email" placeholder="Enter Your Email" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                        @error('email')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    </div>


					<label>Password</label>
					<div class="input-group @error('password') is-invalid @enderror">
						<span class="fa fa-lock" aria-hidden="true"></span>
                        <input id="password" type="Password" placeholder="Enter Password" name="password" required autocomplete="current-password">
                        @error('password')
                        <span class="invalid-feedback" role="alert">
                            <strong>{{ $message }}</strong>
                        </span>
                    @enderror
                    </div>



					<div class="login-check">
						 <label class="checkbox">
                             <input type="checkbox" name="remember" checked=""><i> </i> Remember me</label>
					</div>
                        <button class="btn btn-danger btn-block" type="submit">Login</button >
                            <a class="btn btn-link" href="{{ url('/marketer/password/reset') }}">
                                Forgot Your Password?
                            </a>
                </form>
                {{-- @if (Route::has('password.request'))
                <a class="btn btn-link" href="{{ route('password.request') }}">
                    {{ __('Forgot Your Password?') }}
                </a>
            @endif --}}

            <!--<p class="account1">Dont have an account? <a href="{{ url('marketer/register') }}">Register here</a></p>-->
			</div>
		</div>
		<!-- //main content -->
	</div>
	<!---728x90--->

	<!-- footer -->
	<div class="footer">
		<p>&copy; {{date('Y')}}</p>
	</div>
	<!-- footer -->
</div>


@endsection

