@extends('marketer.layout.master')

@section('template_title')
     Marketer Dashboard
@endsection

@section('content')


    <!-- Header -->
    <div class="header bg-primary pb-6">
      <div class="container-fluid">
        <div class="header-body">
          <div class="row align-items-center py-4">
            <div class="col-lg-6 col-7">

			  <h1 class="display-2 text-white">Welcome {{ Auth::user()->name }}</h1>
            <p class="text-white mt-0 mb-5">{{trans('This is a Marketer portal design for you to Manage your Members activities anytime, anywhere.')}}</p>
            </div>

          </div>
          <!-- Card stats -->
          <div class="row">
            <div class="col-xl-3 col-md-6">
              <div class="card card-stats">
                <!-- Card body -->
                <div class="card-body">
                  <div class="row">
                    <div class="col">
                      <h5 class="card-title text-uppercase text-muted mb-0">Members</h5>
                      <span class="h2 font-weight-bold mb-0">{{$become_a_memberCount}}</span>
                    </div>
                    <div class="col-auto">
                      <div class="icon icon-shape bg-gradient-red text-white rounded-circle shadow">
                        <i class="ni ni-active-40"></i>
                      </div>
                    </div>
                  </div>
                  <p class="mt-3 mb-0 text-sm">
                  <a class="btn btn-success" href="/marketer/member">
                    <span class="text-nowrap">View</span>
                    </a>
                  </p>
                </div>
              </div>
            </div>


          </div>
        </div>
      </div>
    </div>
	<!-- Page content -->



@endsection

