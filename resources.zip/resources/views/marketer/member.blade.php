@extends('marketer.layout.master')

@section('template_title')
    List of Customers
@endsection

@section('content')




    <!-- Header -->
    <div class="header bg-primary pb-6">
            <div class="container-fluid">
              <div class="header-body">
                <div class="row align-items-center py-4">
                  <div class="col-lg-6 col-7">

                    <nav aria-label="breadcrumb" class="d-none d-md-inline-block ml-md-4">
                      <ol class="breadcrumb breadcrumb-links breadcrumb-dark">
                        <li class="breadcrumb-item"><a href="/home"><i class="fas fa-home"></i></a></li>
                        <li class="breadcrumb-item active" aria-current="page">Manage Your Customers</li>
                      </ol>
                    </nav>
                  </div>

                </div>
              </div>
            </div>
          </div>


              <!-- Page content -->
              <div class="container-fluid mt--6">
            <!-- Table -->
            <div class="row">
              <div class="col">

                <div class="card">
                  <!-- Card header -->
                  <div class="card-header">
                    <h3 class="mb-0">Manage Your Customers</h3>

                  </div>
                  <div class="table-responsive py-4">

                        @if (session('delete_message'))
                        <div class="alert alert-success" role="alert">
                            {{ session('delete_message') }}
                        </div>
                    @endif


                    <table class="table table-flush" id="datatable-buttons">
                      <thead class="thead-light">
                            <tr>
                                    <th scope="col">MembershipID</th>
                                    <th scope="col">Full Name</th>
                                    <th scope="col">MarketerEmail</th>
                                    <th scope="col">Phone Number</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                            </tr>
                      </thead>

                      <tbody>

                      @foreach($become_a_member as $item)
                      <tr>
                            <td>{{$item->member_id}}</td>
                            <td>{{$item->first_name}}{{$item->last_name}}</td>
                                <td>{{$item->email}}</td>
                          <td>{{$item->phone}}</td>

                          <td>

                                @if($item->status == 'member unsubscribed')
                                <span class="badge badge-dot mr-4">
                                    <i class="bg-warning"></i>
                                    <span>{{$item->status}}</span>
                                </span>
                              @else($item->status == 'member subscribed')
                                <span class="badge badge-dot mr-4">
                                    <i class="bg-success"></i>
                                    <span>{{$item->status}}</span>
                                </span>
                              @endif
                            </td>


                        <td>

                            {{-- <input type="button" class="btn btn-rounded btn-space btn-primary" value="View" onclick="window.location.href='/viewPayment/{{$item->id}}'" /> --}}

                            <button class="btn btn-info"> <a href="mailto:{{$item->email}}" class="mr-25" data-toggle="tooltip">Send Mail</a></button>



                            </td>
                          </tr>
                        @endforeach


                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          @endsection
