<footer class="main-footer">
	<!-- To the right -->
	<div class="float-right d-none d-sm-block-down">
		Greatlife Fitness
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; {{date('Y')}} <a href="https://animoplasty.com">Developed by Animoplasty</a>.</strong> All rights reserved.
</footer>
