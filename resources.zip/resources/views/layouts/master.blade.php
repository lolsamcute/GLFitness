<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="{{ $pageDescription }}" />
    <meta name="keywords" content="{{ $pageKeywords }}" />
    <meta name="author" content="{{ $pageAuthor }}" />

    <!-- Page Title -->
    <title>{{ $pageTitle }}</title>

     <!-- CSRF Token -->
     <meta name="csrf-token" content="{{ csrf_token() }}">

       {{-- Scripts --}}
       <script>
            window.Laravel = {!! json_encode([
                'csrfToken' => csrf_token(),
            ]) !!};
        </script>

    <!-- favicon icon -->
    <link rel=icon href="Lifestyle and Fitness.png" type="ico/png">

    <link rel="stylesheet" href="assets/font/flaticon.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">


</head>

<body>
    <!-- ===========================
    =====>> Top Preloader <<===== -->
    <div id="preloader">
        <div class="lds-css">
            <div class="preloader-3">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- =====>> End Top Preloader <<=====
    =========================== -->

    <!-- ===========================
    =====>> Top Menu <<===== -->

    <header class="top-nav">
        <!-- Top Address -->
        <div class="top-address">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="top-address-ditels">
                            <ul>
                                <li>
                                    <i class="fas fa-map-marker-alt"></i>
                                    <a target="_blank" href="https://www.google.com/maps/place/Joy+Avenue,+Ajao+Estate,+Lagos/@6.548624,3.3280151,17z/data=!3m1!4b1!4m5!3m4!1s0x103b8e0d0a6d1f97:0x52e45f2b87c2642a!8m2!3d6.5486187!4d3.3302038">16B, Joy Avenue, Ajao Estate, Lagos</a>
                                </li>

                                <li>
                                    <i class="fas fa-phone"></i>
                                    <a href="tel:+234 (813) 5807 485">+234 (813) 5807 485</a>
                                    <a href="tel:+234 (816) 7116 627">, +234 (816) 7116 627</a>
                                </li>
                            </ul>
                        </div>
                        <div class="top-social">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Top Address -->

        <!-- Top Menu -->
        <nav id="cssmenu">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-2">
                        <div class="logo">
                            <a href="/"><img src="assets/img/logo.png" width="80" height="100" alt="logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div id="head-mobile"></div>
                        <div class="button"></div>
                        <ul class="navbar-nav">
                            <li class="active"><a href="/">HOME</a></li>

                            <li><a href="#">SERVICES</a>
                                <ul>
                                     <li><a href="/gym">Gym</a></li>
                                    <li><a href="/spa_appointment">Spa</a></li>
                                    <li><a href="/games_vr">Games & Virtual Reality</a></li>
                                    <li><a href="/beauty_studio">Beauty Studio</a></li>
                                    <li><a href="/lounge_swimming">Lounge & Swimming</a></li>
                                     <li><a href="/food_nutrition">Food & Nutrition</a></li>
                                </ul>
                            </li>

                            <li><a href="/about">ABOUT US</a></li>

                            <!--<li><a href="/trainers">TRAINERS</a></li>-->

                            {{-- <li><a href="#!">FAQ</a></li> --}}

                            <li><a href="/contact">CONTACT</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 text-right p-0 nobile-position">
                        {{-- <div class="shopping-bag">
                            <a class="cart" href="shop.html"><i class="fa fa-shopping-bag"></i><span>0</span></a>
                        </div> --}}
                        <!--<div class="search-dropdown">-->
                        <!--    <button type="button" class="icon-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">-->
                        <!--        <i class="fas fa-search"></i>-->
                        <!--    </button>-->
                        <!--    <form class="dropdown-menu dropdown-menu-right">-->
                        <!--        <input class="search-input " name="search" placeholder="Search " aria-label="Search ">-->
                        <!--        <button class="search-btn " type="submit"><i class="fas fa-search "></i>  </button>-->
                        <!--    </form>-->
                        <!--</div>-->
                        <div class="become-member">
                            <a href="/become_a_member">BECOME A MEMBER</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- End Top Menu -->
    </header>
    <!-- =====>> End Top Menu <<=====
    =========================== -->




  @yield('content')


 <!-- ===========================
    =====>> Footer <<===== -->
    <footer id="footer-area" class="pt-100 pb-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 pt-50">
                    <div class="footer-item">
                        <a href="/" class="footer-logo-img"><img src="assets/img/f-logo.png" width="200" height="100" alt=""></a>
                         <p>Our top notch facility contains all the various ways to relax your mind and body, we have got the full package.</p>

                    </div>
                </div>
                <div class="col-lg-2 offset-lg-1 col-md-4 pt-50">
                    <div class="footer-item">
                        <h6>Useful Links</h6>
                        <ul>
                            <li><a href="/"><i class="fas fa-angle-right"></i> Home</a></li>
                            <li><a href="/about"><i class="fas fa-angle-right"></i> About us</a></li>
                            <li><a href="/faq"><i class="fas fa-angle-right"></i> faq</a></li>

                            <li><a href="/contact"><i class="fas fa-angle-right"></i> Contact</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-2 col-md-4 pt-50">
                    <div class="footer-item">
                        <h6>Services</h6>
                        <ul>
                            <li><a href="/spa"><i class="fas fa-angle-right"></i> Spa</a></li>
                            <li><a href="/games_vr"><i class="fas fa-angle-right"></i> Games & Virtual Reality</a></li>
                            <li><a href="/beauty_studio"><i class="fas fa-angle-right"></i> Beauty Salon</a></li>
                            <li><a href="/lounge_swimming"><i class="fas fa-angle-right"></i> Lounge & Swimming</a></li>
                            <li><a href="/food_nutrition"><i class="fas fa-angle-right"></i> Food & Nutrition</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 pt-50">
                    <div class="footer-item">
                        <h6>Contact Us</h6>
                        <ul class="media">
                            <li><i class="fas fa-map-marker-alt"></i></li>
                            <li><a target="_blank" href="https://www.google.com/maps/place/Joy+Avenue,+Ajao+Estate,+Lagos/@6.548624,3.3280151,17z/data=!3m1!4b1!4m5!3m4!1s0x103b8e0d0a6d1f97:0x52e45f2b87c2642a!8m2!3d6.5486187!4d3.3302038">16B, Joy Avenue,
                                    Ajao Estate, Lagos</a></li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-phone-volume"></i></li>
                            <li><a href="tel:+234 (813) 5807 485">+234 (813) 5807 485</a><br>
                                    <a href="tel:+234 (816) 7116 627">+234 (816) 7116 627</a></li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-envelope"></i></li>
                            <li><a href="mailto:Info@greatlifefitness.com">Info@greatlifefitness.com</a></li>
                        </ul>
                        <ul class="media">
                            <li>
                                    <i class="far fa-clock"></i>
                                    <span>Monday - Saturday :6.00am - 8.00pm</span><br>
                                       <i class="far fa-clock"></i><span>Sunday  :  4.00pm</span>
                                </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="copy-right">© Copyrights {{date('Y')}}. Developed by <a href="https://animoplasty.com/"> Animoplasty.</a> All rights reserved.</div>
                </div>
            </div>
        </div>
    </footer>
    <!-- =====>> End Footer <<=====
    =========================== -->



    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/menu.js"></script>
    <script src="assets/js/scroll-slider.js"></script>
    <script src="assets/js/jquery.parallax-1.1.3.js"></script>
    <script src="assets/js/typing.js"></script>
    <script src="assets/js/contact.js"></script>
    <script src="assets/js/script.js"></script>


</body>

</html>
