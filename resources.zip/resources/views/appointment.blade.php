<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="description" content="{{ $pageDescription }}" />
    <meta name="keywords" content="{{ $pageKeywords }}" />
    <meta name="author" content="{{ $pageAuthor }}" />

    <!-- Page Title -->
    <title>{{ $pageTitle }}</title>

     <!-- CSRF Token -->
     <meta name="csrf-token" content="{{ csrf_token() }}">

       {{-- Scripts --}}
       <script>
            window.Laravel = {!! json_encode([
                'csrfToken' => csrf_token(),
            ]) !!};
        </script>
        
    <!-- favicon icon -->
    <link rel=icon href="/Lifestyle and Fitness.png" type="ico/png">

    <link rel="stylesheet" href="assets/font/flaticon.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">


</head>

<body>
    <!-- ===========================
    =====>> Top Preloader <<===== -->
    <div id="preloader">
        <div class="lds-css">
            <div class="preloader-3">
                <span></span>
                <span></span>
            </div>
        </div>
    </div>
    <!-- =====>> End Top Preloader <<=====
    =========================== -->

    <!-- ===========================
    =====>> Top Menu <<===== -->

    <header class="top-nav">
        <!-- Top Address -->
        <div class="top-address">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="top-address-ditels">
                            <ul>
                                <li>
                                    <i class="fas fa-map-marker-alt"></i>
                                    <a target="_blank" href="https://www.google.com/maps/place/Joy+Avenue,+Ajao+Estate,+Lagos/@6.548624,3.3280151,17z/data=!3m1!4b1!4m5!3m4!1s0x103b8e0d0a6d1f97:0x52e45f2b87c2642a!8m2!3d6.5486187!4d3.3302038">16B, Joy Avenue, Ajao Estate, Lagos</a>
                                </li>
                                <li>
                                    <i class="fas fa-phone"></i>
                                    <a href="tel:+234 (813) 5807 485">+234 (813) 5807 485</a>
                                    <a href="tel:+234 (816) 7116 627">, +234 (816) 7116 627</a>
                                </li>
                            </ul>
                        </div>
                        <div class="top-social">
                            <a href="#"><i class="fab fa-facebook-f"></i></a>
                            <a href="#"><i class="fab fa-twitter"></i></a>
                            <a href="#"><i class="fab fa-instagram"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Top Address -->

        <!-- Top Menu -->
        <nav id="cssmenu">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-2">
                        <div class="logo">
                                <a href="/"><img src="assets/img/logo.png" width="80" height="100" alt="logo"></a>
                        </div>
                    </div>
                    <div class="col-lg-7 col-md-12">
                        <div id="head-mobile"></div>
                        <div class="button"></div>
                         <ul class="navbar-nav">
                            <li><a href="/">HOME</a></li>
                            
                             <li class="active"><a href="#">SERVICES</a>
                                <ul>
                                     <li><a href="/gym">Gym</a></li>
                                    <li><a href="/spa_appointment">Spa</a></li>
                                    <li><a href="/games_vr">Games & Virtual Reality</a></li>
                                    <li><a href="/beauty_studio">Beauty Studio</a></li>
                                    <li><a href="/lounge_swimming">Lounge & Swimming</a></li>
                                     <li><a href="/food_nutrition">Food & Nutrition</a></li>
                                </ul>
                            </li>

                            <li><a href="/about">ABOUT US</a></li>
                            
                            <!--<li><a href="/trainers">TRAINERS</a></li>-->

                              {{-- <li><a href="/faq">FAQ</a></li> --}}

                            <li><a href="/contact">CONTACT</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 text-right p-0 nobile-position">
                        {{-- <div class="shopping-bag">
                            <a class="cart" href="shop.html"><i class="fa fa-shopping-bag"></i><span>0</span></a>
                        </div> --}}
                        <!--<div class="search-dropdown">-->
                        <!--    <button type="button" class="icon-btn" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">-->
                        <!--        <i class="fas fa-search"></i>-->
                        <!--    </button>-->
                        <!--    <form class="dropdown-menu dropdown-menu-right">-->
                        <!--        <input class="search-input " name="search" placeholder="Search " aria-label="Search ">-->
                        <!--        <button class="search-btn " type="submit"><i class="fas fa-search "></i>  </button>-->
                        <!--    </form>-->
                        <!--</div>-->
                        <div class="become-member">
                            <a href="/become_a_member">BECOME A MEMBER</a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
        <!-- End Top Menu -->
    </header>
    <!-- =====>> End Top Menu <<=====
    =========================== -->




 <!-- ===========================
    =====>> Page Hero <<===== -->
    <section id="page-hero" class="about-bgSpa">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title text-center">
                        <h1>Spa <span>Appointment</span></h1>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Page Hero <<=====
    =========================== -->

    <section id="blog-arae" class="pt-150 pb-150">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="blog-single-contetn">
                            <div class="blog-single-img">
                                <img src="/4X9A9350.JPG" alt="">
                            </div>
                            <div class="blog-single-text">

                                <p>You know you deserve to be pampered, so walk into our relaxation spa and indulge in our deep cleansing facials, exfoliating scrub, body waxing, body polishing, sauna baths and lots more. Lose yourself in our signature spa treatments specially designed to reconnect your mind, body and spirit, in a calm and rejuvenating atmosphere. We have got what it takes at Great life fitness and lifestyle Spa to keep you nourished and refreshed.</p>
                                
                                
                                
                                <h3>Here are some of our massage services:</h3>
                                
                                
                                <ul>
  <li><b><a href="#!"><i class="fas fa-angle-right"></i>Swedish relaxation massage: </b>This is perfect for you if it’s your first time at a spa, or perhaps you just need something to help you relax. A variety of soft warm up massages on the muscle helps release tension and stress. Swedish massage promotes relaxation, improves sleep and eases muscle tension.</a> </li>
  
  <li><b><a href="#!"><i class="fas fa-angle-right"></i>Deep tissue massage: </b>To get relief from muscle stiffness and pain, it is best you get a deep tissue massage. Deep tissue massage applies more pressure than Swedish. It works below the surface to penetrate the deeper into the muscles and work out chronic tension and stress. </a></li>
  
    <li><b><a href="#!"><i class="fas fa-angle-right"></i>Reflexology: </b>This is an age-long technique that stimulates the body’s healing process that focuses on the feet. It is also known as foot massage. Specific pressure points in the foot are directly linked to several organs in the body.  When these pressure points are kneaded, it effectively releases tension throughout the body and influences the natural flow of energy. </a></li>
    
        <li><b><a href="#!"><i class="fas fa-angle-right"></i>Hot-stone massage: </b>Don’t be scared by the name “hot stones”, they are basically warm-soothing stones that helps melt away stress and stiffness. The Stones would be placed on strategic parts of the body while the therapist gives the massage.</a></li>
        
          <li><b><a href="#!"><i class="fas fa-angle-right"></i>Aromatherapy: </b>Using products like bathing salts, body oils, creams, lotion, clay mask and lots more for massage. Aromatherapy helps to manage, soothe sore joints, and improve sleep quality. It also clears the airways and improves respiration. </a></li>
</ul>


                            </div>

                        </div>
                    </div>
                    <div class="col-lg-4 pl-5">
                        <div class="blog-widget-right">
      
                            <div class="popular-news">
                                <h5>Gallery</h5>
                                
                                <div class="popular-news-item">
                                    <img src="/4X9A9355.JPG" alt="">
                                    <h6><a href="/4X9A9355.JPG"></a></h6>

                                </div>
                                <div class="popular-news-item">
                                    <img src="/4X9A9345.jpg" alt="">
                                    <h6><a href="/4X9A9345.jpg"></a></h6>

                                </div>
                                <div class="popular-news-item">
                                    <img src="/4X9A9301.JPG" alt="">
                                    <h6><a href="/4X9A9301.JPG"></a></h6>

                                </div>
                                <div class="popular-news-item">
                                    <img src="/4X9A9298.JPG" alt="">
                                    <h6><a href="/4X9A9298.JPG"></a></h6>

                                </div>
                                
                                 <div class="popular-news-item">
                                    <img src="/4X9A9217.JPG" alt="">
                                    <h6><a href="/4X9A9217.JPG"></a></h6>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
 




    <!-- ===========================
    =====>> Contact <<===== -->
    <section id="contact-area" class="pt-150 pb-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contaict-title">
                        <h2>Please use our electronic form to book a date. </h2>
                    </div>
                </div>
                <div class="col-lg-8">
                        @if (session('spa_message'))
                        <div class="alert alert-success" role="alert">
                            {{ session('spa_message') }}
                        </div>
                    @endif


                    <form action="/spa_appointment" method="POST" class="contact-box">
                        {!! csrf_field() !!}

                        <input type="text" name="full_name" placeholder="Full Name" required>
                        <input type="email" name="email" placeholder="Email" required>
                        <input type="number" name="phone" placeholder="Phone" required>
                        <input  type="text" name="address" placeholder="Address" required>
                        <input  type="date" name="date" placeholder="Book Date" required>
                        <select name="sex" class="contact-box" required>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>

                        <select name="members_name" class="contact-box" required>
                                <option value="***" selected>Please Select Your Referral Marketer</option>
                                @foreach($marketers as $item)
                            <option value="{{$item -> name}}">{{$item->name}}</option>
                            @endforeach
                            <option value="***">Other</option>
                        </select>


                        {{-- <input  type="text" name="address" placeholder="Address"> --}}
                        <button type="submit" class="btn btn-7">Submit</button>
                    </form>

                </div>
                <div class="col-lg-4 ">
                    <div class="contact-ditels m-lg-2">
                        <ul class="media">
                            <li><i class="fas fa-envelope"></i></li>
                            <li>
                                <a href="#">Info@yourmail.com</a>
                                <br>
                                <a href="#">Info2@yourmail.com</a>
                            </li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-phone-volume"></i></li>
                            <li>
                                <a href="#">+234 12 123 4567</a> </br>
                                <a href="#">+234 222 345 342</a>
                            </li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-map-marker-alt"></i></li>
                            <li>
                                <a target="_blank" href="https://www.google.com/maps/place/Joy+Avenue,+Ajao+Estate,+Lagos/@6.548624,3.3280151,17z/data=!3m1!4b1!4m5!3m4!1s0x103b8e0d0a6d1f97:0x52e45f2b87c2642a!8m2!3d6.5486187!4d3.3302038">
                                    Joy Avenue, Ajao Estate, Lagos</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Contact <<=====
    =========================== -->


<!-- ===========================
    =====>> Footer <<===== -->
    <footer id="footer-area" class="pt-100 pb-150">
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 pt-50">
                        <div class="footer-item">
                            <a href="/" class="footer-logo-img"><img src="assets/img/f-logo.png" width="200" height="100" alt=""></a>
                            <p>Our top notch facility contains all the various ways to relax your mind and body, we have got the full package.</p>

                        </div>
                    </div>
                    <div class="col-lg-2 offset-lg-1 col-md-4 pt-50">
                        <div class="footer-item">
                            <h6>Useful Links</h6>
                            <ul>
                                <li><a href="/"><i class="fas fa-angle-right"></i> Home</a></li>
                                <li><a href="/about"><i class="fas fa-angle-right"></i> About us</a></li>
                                <li><a href="/faq"><i class="fas fa-angle-right"></i> faq</a></li>

                                <li><a href="/contact"><i class="fas fa-angle-right"></i> Contact</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 pt-50">
                    <div class="footer-item">
                        <h6>Services</h6>
                        <ul>
                            <li><a href="/spa"><i class="fas fa-angle-right"></i> Spa</a></li>
                            <li><a href="/games_vr"><i class="fas fa-angle-right"></i> Games & Virtual Reality</a></li>
                            <li><a href="/beauty_studio"><i class="fas fa-angle-right"></i> Beauty Salon</a></li>
                            <li><a href="/lounge_swimming"><i class="fas fa-angle-right"></i> Lounge & Swimming</a></li>
                            <li><a href="/food_nutrition"><i class="fas fa-angle-right"></i> Food & Nutrition</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-md-4 pt-50">
                    <div class="footer-item">
                        <h6>Contact Us</h6>
                        <ul class="media">
                            <li><i class="fas fa-map-marker-alt"></i></li>
                            <li><a target="_blank" href="https://www.google.com/maps/place/Joy+Avenue,+Ajao+Estate,+Lagos/@6.548624,3.3280151,17z/data=!3m1!4b1!4m5!3m4!1s0x103b8e0d0a6d1f97:0x52e45f2b87c2642a!8m2!3d6.5486187!4d3.3302038">16B, Joy Avenue,
                                    Ajao Estate, Lagos</a></li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-phone-volume"></i></li>
                                <li><a href="tel:+234 (813) 5807 485">+234 (813) 5807 485</a><br>
                                    <a href="tel:+234 (813) 5807 485">+234 (816) 7116 627</a></li>
                        </ul>
                        <ul class="media">
                            <li><i class="fas fa-envelope"></i></li>
                            <li><a href="mailto:Info@greatlifefitness.com">Info@greatlifefitness.com</a></li>
                        </ul>
                        <ul class="media">
                            <li>
                                    <i class="far fa-clock"></i>
                                    <span>Monday - Saturday :6.00am - 8.00pm</span><br>
                                       <i class="far fa-clock"></i><span>Sunday  :  4.00pm</span>
                                </li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="copy-right">© Copyrights {{date('Y')}}. Developed by <a href="https://animoplasty.com/"> Animoplasty.</a> All rights reserved.</div>
                </div>
            </div>
        </div>
    </footer>
    <!-- =====>> End Footer <<=====
    =========================== -->



    <script src="assets/js/jquery-3.3.1.min.js"></script>
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/menu.js"></script>
    <script src="assets/js/scroll-slider.js"></script>
    <script src="assets/js/jquery.parallax-1.1.3.js"></script>
    <script src="assets/js/typing.js"></script>
    <script src="assets/js/contact.js"></script>
    <script src="assets/js/script.js"></script>


</body>

</html>
