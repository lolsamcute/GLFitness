@extends('layouts.master')

@section('content')

    <!-- ===========================
    =====>> Page Hero <<===== -->
    <section id="page-hero" class="about-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title text-center">
                            <h1><span>Application</span>  Form</h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Page Hero <<=====
        =========================== -->


    <!-- ===========================
    =====>> Bmi <<===== -->
    <section id="bmi-area" class="bmi-bg parallax pt-150 pb-150">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-8">
                        <div class="section-title text-left">
                            <h2>Registration <span>Here</span></h2>
                            <p>For New members, Join us and experience our superb center </p>
                        </div>
                    </div>
                </div>
                <div class="bmi-content pt-80">
                    <div class="row">
                        <div class="col-lg-8">
                            <!-- bmi nav -->
                            <ul class="bmi-tabs bmi-tab-btn">
                                <li class="tab-link current" data-tab="tabs-1">New Member</li>
                                <!--<li class="tab-link" data-tab="tabs-2">Renewal Member</li>-->
                            </ul>

                            <div id="tabs-1" class="tab-content2 current">


                                    <form action="/become_a_member" method="POST" class="row">
                                        {!! csrf_field() !!}

                                    <div class="col-12">
                                        <h3>Personal Information</h3>
                                    </div>
                                    <div class="col-6">
                                        <input type="text" class="input" name="first_name" placeholder="First Name" required>
                                    </div>
                                        <div class="col-6">
                                    <input type="text" class="input" name="last_name" placeholder="Last Name" required><br><br>
                                    </div>

                                    <div class="col-6">
                                  <input type="email" class="input" name="email" placeholder="Email" required><br><br>
                                </div>

                                <div class="col-6">
                                        <input type="number" class="input" name="phone" placeholder="Phone Number" required><br><br>
                                   </div>
                                  <div class="col-6">
                                        <select class="input" name="membership_package" required>
                                                @foreach($packages as $item)
                                            <option value="{{$item -> amount}}" selected>{{$item -> name}} PACKAGE - ₦{{ number_format($item -> amount)}}</option>
                                            @endforeach
                                        </select>
                                        <br><br>

                                    </div>

                                    <div class="col-6">
                                        <p>Cheque & Cash should be paid in the center</p><br>

                                        <select class="input" name="paymentMethod" required>
                                                <option value="***" selected>Payment Method</option>
                                                <option value="Card">Card</option>

                                        </select>
                                        <br><br>
                                    </div>


                                        <div class="col-12">

                                        <label class="col-12 col-sm-3 col-form-label text-sm-right">Please select your duration?</label>

                                          <label class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" type="radio" name="duration" value="1 Month" checked=""><span class="custom-control-label">1 Month</span>
                                          </label>
                                          <label class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" type="radio" name="duration" value="3 Months"><span class="custom-control-label">3 Months</span>
                                          </label>
                                          <label class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" type="radio" name="duration" value="6 Months"><span class="custom-control-label">6 Months</span>
                                          </label>

                                          <label class="custom-control custom-radio custom-control-inline">
                                            <input class="custom-control-input" type="radio" name="duration" value="1 Year"><span class="custom-control-label">1 Year</span>
                                          </label>


                                      <br><br>








                                    <input type="text" class="input" name="address" placeholder="Address" required><br><br>


                                        <select class="input" name="hearAbout" required>
                                                <option value="***" selected>How do you hear about us?</option>
                                                <option value="Website/Online Search Engine">Website/Online Search Engine</option>
                                                <option value="Driving/Walking pass">Driving/Walking pass</option>
                                                <option value="Leaflet">Leaflet</option>
                                                <option value="Other(Please Specify)">Other(Please Specify)</option>


                                        </select>
                                        <br><br>

                                   <input type="text" class="input" name="hearAboutOther" placeholder="If Other(Please fill)"><br><br>



                                            <select class="input" name="members_name" required>
                                                    <option value="***" selected>Please Select Your Referral Sales Representive (If Applicable)</option>
                                                    @foreach($marketers as $item)
                                                <option value="{{$item -> name}}">{{$item->name}}</option>
                                                @endforeach

                                            </select>
                                    </div>



                                            <button type="submit" class="btn container-btn btn-1"> Get Started </button>



                                </form>


                            </div>
                            <!--<div id="tabs-2" class="tab-content2">-->

                            <!--        <form action="/become_a_memberExisiting" method="POST" class="row">-->
                            <!--            {!! csrf_field() !!}-->

                            <!--            <div class="col-12">-->
                            <!--                    <h3>Personal Information</h3>-->
                            <!--                    <p>Please Note: We recognised your as our Exisitng memeber. After your form is submitted. Ensure you show our Front Desk Representative your Membership ID for Payment process.</p><br>-->
                            <!--                </div>-->

                            <!--                <div class="col-12">-->
                            <!--                <input type="text" class="input" name="memberID" placeholder="Membership ID" required><br><br>-->

                            <!--               <input type="email" class="input" name="email" placeholder="Email" required>-->
                            <!--               <br><br>-->
                            <!--              <input type="text" class="input" name="number" placeholder="Phone Number" required>-->

                            <!--            </div>-->

                            <!--                <div class="col-6"><button type="submit" class="btn container-btn btn-5"> Get Started </button></div>-->
                            <!--    </form>-->



                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Bmi <<=====
        =========================== -->

        @endsection
