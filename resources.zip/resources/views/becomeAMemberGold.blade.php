@extends('layouts.master')

@section('content')

    <!-- ===========================
    =====>> Page Hero <<===== -->
    <section id="page-hero" class="about-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title text-center">
                            <h1><span>Gold</span> Application Form</h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Page Hero <<=====
        =========================== -->


    <!-- ===========================
    =====>> Bmi <<===== -->
    <section id="bmi-area" class="bmi-bg parallax pt-150 pb-150">
            <div class="container">
                <div class="row ">
                    <div class="col-lg-8">
                        <div class="section-title text-left">
                            <h2>Registration <span>Here</span></h2>
                            <p>For New members, we have free 5 days available. Join us and experience our superb center </p>
                        </div>
                    </div>
                </div>
                <div class="bmi-content pt-80">
                    <div class="row">
                        <div class="col-lg-6">
                            <!-- bmi nav -->
                            <ul class="bmi-tabs bmi-tab-btn">
                                <li class="tab-link current" data-tab="tabs-1">New Member</li>
                                <li class="tab-link" data-tab="tabs-2">Renewal Member</li>
                            </ul>

                            <div id="tabs-1" class="tab-content2 current">


                                    <form action="/become_a_member" method="POST" class="row">
                                        {!! csrf_field() !!}

                                    <div class="col-12">
                                        <h3>Personal Information</h3>
                                    </div>
                                    <div class="col-6"><input type="text" class="input" name="first_name" placeholder="First Name" required></div>
                                    <div class="col-6"><input type="text" class="input" name="last_name" placeholder="Last Name" required></div>
                                    <div class="col-12"><input type="email" class="input" name="email" placeholder="Email" required></div>
                                    <div class="col-12">
                                            <select class="input" name="membership_package" required>
                                                <option value="Silver" selected>Gold Package - 35,000</option>
                                            </select>
                                        </div>

                                    <div class="col-12"><input type="number" class="input" name="phone" placeholder="Phone Number" required></div>
                                    <div class="col-12"><input type="text" class="input" name="address" placeholder="Address" required></div>

                                    <div class="col-6">

                                            <button type="submit" class="btn container-btn btn-1"> Get Started </button>

                                    </div>
                                </form>


                            </div>
                            <div id="tabs-2" class="tab-content2">

                                    <form action="/become_a_memberExisiting" method="POST" class="row">
                                        {!! csrf_field() !!}

                                        <div class="col-12">
                                                <h3>Personal Information</h3>
                                            </div>
                                            <div class="col-12"><input type="text" class="input" name="memberID" placeholder="Membership ID" required></div>

                                            <div class="col-12"><input type="email" class="input" name="email" placeholder="Email" required></div>
                                            <div class="col-12"><input type="text" class="input" name="number" placeholder="Phone Number" required></div>
                                            <div class="col-12"><input type="text" class="input" name="address" placeholder="Address" required></div>

                                    <div class="col-6"><a href="#" class="btn container-btn2 btn-5">Submit</a></div>
                                </form>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Bmi <<=====
        =========================== -->

        @endsection
