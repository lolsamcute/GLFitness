@extends('layouts.master')

@section('content')

    <!-- ===========================
    =====>> Page Hero <<===== -->
    <section id="page-hero" class="about-bg">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="page-title text-center">
                            <h1>Become A <span>Member</span></h1>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Page Hero <<=====
        =========================== -->




    <!-- ===========================
    =====>> Pricing <<===== -->
    <section id="pricing-area" class="pt-150">
            <div class="container ">
                <div class="row ">
                    <div class="col-lg-8 offset-lg-2 ">
                        <div class="section-title text-center ">
                            <h2>Membership <span>Pricing</span></h2>
                            <p>Kick your feet up! With a gym designed around you, we think
                                <br> you’ll love it here.</p>
                        </div>
                    </div>
                </div>
                <div class="pricing-content pt-40">
                    <div class="row">
                        <!-- Pricing Item -->


                        @foreach($packages as $item)
                        <div class="col-lg-6 mt-40">
                            <div class="pricing-item media">
                                <div class="pricing-item-left">
                                    <ul>
                                        <li>
                                            <h3 class="pricing-item-left-h3">CLASSIC MEMBERSHIP </h3>
                                        </li>
                                        <li>
                                            <h3 class="pricing-item-left-h3">{{$item -> name}} PLAN </h3>
                                            {{-- <h6 class="pricing-item-left-h6">Spend ten, get tons</h6> --}}
                                        </li>
                                        <li>
                                            <h2 class="pricing-item-left-h2">₦{{ number_format($item -> amount)}} /mo</h2>
                                            {{-- <p class="pricing-item-left-p">plus taxes and fees</p> --}}
                                        </li>
                                    </ul>
                                </div>
                                <div class="pricing-item-right">
                                    <ul>
                                        <li><a href="#"><i class="fas fa-check-circle "></i> Unlimited Access to Home Club</a></li>
                                        <li><a href="#"><i class="fas fa-check-circle "></i> Free Fitness Training</a></li>
                                        <li><a href="#"><i class="fas fa-check-circle "></i> Free training session with a Club</a></li>
                                        <li><a href="#"><i class="fas fa-check-circle "></i> Access to the Swimming pool  </a></li>

                                    </ul>


                                    <a href="/become_a_member_form" class="btn btn-3">Get Started</a>
                                </div>
                            </div>
                        </div>

                        @endforeach

                    </div>
                </div>
            </div>
        </section>
        <!-- =====>> End Pricing <<=====
        =========================== -->


@endsection
