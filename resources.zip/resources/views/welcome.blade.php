@extends('layouts.master')

@section('content')



    <!-- ===========================
    =====>> Hero <<===== -->
    <section id="Home-area" class="header">
        <div class="fullslider owl-carousel owl-theme ">
            <!-- slider item -->
            <div class="item slider-bg-1 ">
                <div class="container ">
                    <div class="row ">
                        <div class="col-lg-8 text-left dis-tab ">
                            <div class="slider-all-text ">
                                <h1>Welcome to GreatLife Fitness & Lifestyle Center</h1>
                                <p>Live Strong, Live Long </p>

                                <a class="video-play-button " href="https://www.youtube.com/watch?v=g994ygh8iXY">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- slider item -->
            <div class="item slider-bg-2">
                <div class="container ">
                    <div class="row ">
                        <div class="col-lg-8 text-left dis-tab ">
                            <div class="slider-all-text ">
                                <h1>SPA</h1>
                                <p> Give yourself time to unwind in our Sauna Spa, you know you deserve it.</p>
                                 <br><br><br><br><br><br><br>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=g994ygh8iXY">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- slider item -->
            <div class="item slider-bg-4">
                <div class="container ">
                    <div class="row ">
                        <div class="col-lg-8 text-left dis-tab ">
                            <div class="slider-all-text ">
                                <h1>Gym</h1>
                                <p>Your fitness & health is our optimum priority</p>
                                <br><br><br><br><br><br><br><br><br>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=g994ygh8iXY">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- slider item -->
            <div class="item slider-bg-6">
                <div class="container ">
                    <div class="row ">
                        <div class="col-lg-8 text-left dis-tab ">
                            <div class="slider-all-text ">
                                <h1>Beauty Studio</h1>
                                <p>This is the place where stars are made, so lets make you shine</p>
                                <br><br><br><br><br><br><br><br><br>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=g994ygh8iXY">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- slider item -->
            <div class="item slider-bg-3">
                <div class="container ">
                    <div class="row ">
                        <div class="col-lg-8 text-left dis-tab ">
                            <div class="slider-all-text ">
                                <h1>Games & Relaxation</h1>
                                <p>Have fun with Friends & Family in a serena Enviroment  with lots of Entertainment.</p>
                                <br><br><br><br><br><br><br>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=g994ygh8iXY">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Hero <<=====
    =========================== -->

    <!-- ===========================
    =====>> About Box <<===== -->
    <section id="about-box">
        <div class="container-fluid ">
            <div class="row ">
                <div class="col-lg-3 about-box-left-bc p-0 ">
                    <div class="about-box-left-img "></div>
                    <div class="about-box-left ">
                        <h2>Membership starts from <span>₦20,000</span> monthly </h2>
                        <!--<p>Every member gets a free personalized trainer, Get Started Plan when they join. </p>-->
                        <a href="/become_a_member" class="btn btn-2">Get Started</a>
                    </div>
                </div>
                <div class="col-lg-9 p-0 ">
                    <div class="about-box-right media">
                        <div class="about-box-right-img "></div>
                        <h2>Try us for
                            <br> <span>Aerobics</span> & Yoga Class</h2>
                        <a href="/become_a_member" class="btn btn-1">Get GYM PASS</a>
                    </div>
                    <div id="main">
                        <div class="slideFrame" id="slider-0">
                            <ul class="slideGuide left ">
                                <li class="slideCell ">
                                    <img src="/4X9A6379.jpg" alt=" ">
                                    <!--<div class="sliderCell-text ">-->
                                    <!--    <h2>Fit Equipment </h2>-->
                                    <!--    <h3>For Every Goal</h3>-->
                                    <!--    <p>Let our knowledgeable team get you started with a one-on-one workout session</p>-->
                                    <!--</div>-->
                                </li>
                                <li class="slideCell ">
                                    <img src="/4X9A6462.jpg" alt=" ">
                                    <!--<div class="sliderCell-text ">-->
                                    <!--     <h2>Fit Equipment </h2>-->
                                    <!--    <h3>For Every Goal</h3>-->
                                    <!--    <p>Let our knowledgeable team get you started with a one-on-one workout session</p>-->
                                    <!--</div>-->
                                </li>
                                <li class="slideCell ">
                                    <img src="/4X9A6387.jpg" alt=" ">
                                    <!--<div class="sliderCell-text ">-->
                                    <!--     <h2>Fit Equipment </h2>-->
                                    <!--    <h3>For Every Goal</h3>-->
                                    <!--    <p>Let our knowledgeable team get you started with a one-on-one workout session</p>-->
                                    <!--</div>-->
                                </li>
                                <li class="slideCell ">
                                    <img src="/4X9A6390.jpg" alt=" ">
                                    <!--<div class="sliderCell-text ">-->
                                    <!--      <h2>Fit Equipment </h2>-->
                                    <!--    <h3>For Every Goal</h3>-->
                                    <!--    <p>Let our knowledgeable team get you started with a one-on-one workout session</p>-->
                                    <!--</div>-->
                                </li>
                                <li class="slideCell ">
                                    <img src="/4X9A6458.jpg" alt=" ">
                                    <!--<div class="sliderCell-text ">-->
                                    <!--     <h2>Fit Equipment </h2>-->
                                    <!--    <h3>For Every Goal</h3>-->
                                    <!--    <p>Let our knowledgeable team get you started with a one-on-one workout session</p>-->
                                    <!--</div>-->
                                </li>

                            </ul>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End About Box <<=====
    =========================== -->

    <!-- ===========================
    =====>> Fitner <<===== -->
    <section id="fitner-area" class="pt-150">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="section-title text-center">
                        <h2>Why Choose <span>Us</span>? </h2>
                        <p>Your fitness and health is our optimum priority!
This is no discrimination zone; come as you are and soon we will get you in love with your body. Life is beautiful!
                         </p>
                    </div>
                </div>
            </div>
            <div class="fitner-content pt-40 ">
                <div class="row ">
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <!-- fitner item -->
                        <div class="fitner-item fitner-border mt-40">
                            <img src="assets/img/icon/2.png"  alt=" ">
                            <h2> Fitness Classes </h2>
                            <p>Stop stalling. Achieve your body goals with our daily fitness sessions. You wouldn't know what you are capable of until you do it! Our relentless instructors will push you till you love who you see in the mirror. Let's go!</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6">
                        <!-- fitner item -->
                        <div class="fitner-item fitner-border mt-40">
                            <img src="/beauty.jpeg" height="110" width="100" alt=" ">
                            <h2>Beauty Makeover & Massage Therapy</h2>
                            <p>Give yourself time to unwind in our Sauna/Spa, you know you deserve it.
We are charged with the responsibility of making you look amazing. Our Salon is the place where stars are made, so let's.make you shine!</p>
                        </div>
                    </div>
                    <div class="col-lg-4 offset-lg-0 col-md-6 offset-md-3 col-sm-6 offset-sm-3">
                        <!-- fitner item -->
                        <div class="fitner-item mt-40">
                            <img src="/relaxation.jpeg" height="110" width="100" alt=" ">
                            <h2>Relaxation & Healthy Living</h2>
                            <p>Have fun with friends and family in serene environment with lots of entertainment accompanied by healthy refreshments to tease your tastebuds.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Fitner <<=====
    =========================== -->

    <!-- ===========================
    =====>> Services <<===== -->
    <section id="services-area" class="pt-150">
        <div class="container ">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 ">
                    <div class="section-title text-center ">
                        <h2>What to get from <span>Greatlife Fitness </span>Membership </h2>
                        <p>Kick your feet up! With a gym designed around you, we think
                            <br> you’ll love it here.</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="service-content pt-40 ">
            <div class="container-fluid ">
                <div class="row ">

                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                        <div class="services-box effect-item mt-40">
                            <div class="services-item content-overlay">
                                <img src="/godwin.png" height="220" alt="/godwin.png">
                                <div class="content-details fadeIn-top">
                                    <i class="flaticon-male-arm-muscles "></i>
                                    <a href="#!"><h3>Fitness</h3></a>
                                    <p>Your fitness & health is our optimum priority</p>
                                </div>
                            </div>
                            <div class="services-text text-center">
                                <i class="flaticon-male-arm-muscles "></i>
                                <h3>Fitness</h3>
                            </div>
                        </div>
                    </div>

                     <!-- Service Item -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                        <div class="services-box effect-item mt-40">
                            <div class="services-item content-overlay">
                                <img src="/4X9A6469.jpg" alt=" ">
                                <div class="content-details fadeIn-top">
                                    <i class="flaticon-calories "></i>
                                    <a href="#!"><h3>Beauty Salon</h3></a>
                                    <p>Our Salon is the place where stars are made, so lets make you shine</p>
                                </div>
                            </div>
                            <div class="services-text text-center">
                                <i class="flaticon-calories "></i>
                                <h3>Beauty Salon </h3>
                            </div>
                        </div>
                    </div>


                    <!-- Service Item -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                        <div class="services-box effect-item mt-40">
                            <div class="services-item content-overlay">
                                <img src="/4X9A9331.JPG" alt=" ">
                                <div class="content-details fadeIn-top">
                                    <i class="flaticon-male-silhouette-variant-showing-muscles "></i>
                                    <a href="#!"><h3>Games & Virtual Reality</h3></a>
                                    <p>Have fun with Friends & Family in a serena Enviroment  with lots of Entertainment.</p>
                                </div>
                            </div>
                            <div class="services-text text-center">
                                <i class="flaticon-male-silhouette-variant-showing-muscles "></i>
                                <h3>Games & Virtual Reality</h3>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->


                    <!-- Service Item -->
                    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6">
                        <div class="services-box effect-item mt-40">
                            <div class="services-item content-overlay">
                                <img src="/IMG_6444.jpg" alt=" ">
                                <div class="content-details fadeIn-top">
                                    <i class="flaticon-treadmill "></i>
                                    <a href="#!"><h3>Relaxation Lounge </h3></a>
                                    <p>Have fun with Friends & Family in a serena Enviroment  with lots of Entertainment.</p>
                                </div>
                            </div>
                            <div class="services-text text-center">
                                <i class="flaticon-treadmill "></i>
                                <h3>Relaxation Lounge </h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Services <<=====
    =========================== -->


    <!-- ===========================
    =====>> Pricing <<===== -->
    <!--<section id="pricing-area" class="pt-150">-->
    <!--    <div class="container ">-->
    <!--        <div class="row ">-->
    <!--            <div class="col-lg-8 offset-lg-2 ">-->
    <!--                <div class="section-title text-center ">-->
    <!--                    <h2>fitner membership <span>Pricing</span></h2>-->
    <!--                    <p>Kick your feet up! With a gym designed around you, we think-->
    <!--                        <br> you’ll love it here.</p>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="pricing-content pt-40">-->
    <!--            <div class="row">-->
    <!--                    @foreach($packages as $item)-->
    <!--                    <div class="col-lg-6 mt-40">-->
    <!--                        <div class="pricing-item media">-->
    <!--                            <div class="pricing-item-left">-->
    <!--                                <ul>-->
    <!--                                    <li>-->
    <!--                                        <h3 class="pricing-item-left-h3">MEMBERSHIP </h3>-->
    <!--                                    </li>-->
    <!--                                    <li>-->
    <!--                                        <h3 class="pricing-item-left-h3">{{$item -> name}} PLAN </h3>-->
    <!--                                        {{-- <h6 class="pricing-item-left-h6">Spend ten, get tons</h6> --}}-->
    <!--                                    </li>-->
    <!--                                    <li>-->
    <!--                                        <h2 class="pricing-item-left-h2">₦{{ number_format($item -> amount)}} /mo</h2>-->
    <!--                                        {{-- <p class="pricing-item-left-p">plus taxes and fees</p> --}}-->
    <!--                                    </li>-->
    <!--                                </ul>-->
    <!--                            </div>-->
    <!--                            <div class="pricing-item-right">-->

    <!--                                    {!!$item->plans!!}-->





    <!--                                <a href="/become_a_member_form" class="btn btn-3">Get Started</a>-->
    <!--                            </div>-->
    <!--                        </div>-->
    <!--                    </div>-->

    <!--                    @endforeach-->

    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    <!-- =====>> End Pricing <<=====
    =========================== -->

    <!-- ===========================
    =====>> Feature <<===== -->
    <section id="feature-area" class="pt-100 pb-150">
        <div class="container">
            <div class="row">
                <!-- Feature Item -->
                <div class="col-lg-4 col-md-6">
                    <div class="feature-item media mt-50">
                        <div class="feature-i">
                            <i class="flaticon-dumbbell-1"></i>
                        </div>
                        <div class="feature-text">
                            <h3>Customer Satisfaction</h3>
                            <p>Over 200+ customers trust us with their fitness and health goals. Our major desire is for you to "Live Long and Live Strong", so let's do this together!</p>
                        </div>
                    </div>
                </div>
                <!-- Feature Item -->
                <div class="col-lg-4 col-md-6">
                    <div class="feature-item media mt-50">
                        <div class="feature-i">
                            <i class="flaticon-clock"></i>
                        </div>
                        <div class="feature-text">
                            <h3>Open 24/7</h3>
                            <p>We are always available and at your service. Our clients satisfaction is a priority all day long.</p>
                        </div>
                    </div>
                </div>
                <!-- Feature Item -->
                <div class="col-lg-4 offset-lg-0 col-md-6 offset-md-3">
                    <div class="feature-item media mt-50">
                        <div class="feature-i">
                            <i class="flaticon-juice"></i>
                        </div>
                        <div class="feature-text">
                            <h3>Foods Guildeline</h3>
                            <p>We establish the best food and nutrition recommendations to foster healthy eating habits and quality lifestyle of our customers.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Feature <<=====
    =========================== -->
        <section id="testimonial-area">
               <div class="container ">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 ">
                    <div class="section-title text-center ">
                        <h2>Gift Coupon</h2>
                           <p>Want to show love to someone you admire, but don't know how?<br>

Send them a gift coupon!

<br>Get them to enjoy a day at our exclusive recreational centre, they will love you for it. <br>

Take advantage of our amazing deals and send your colleagues, friends and family a gift coupon NOW!</p>
                    </div>
                </div>
            </div>
        </div>

     <div class="testimonial-content pt-40">
                <div class="row">
                    <!-- Testimonial Item -->
                    <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/Asset 9.png" alt="">
                            <!--<div class="testimonial-text">-->
                            <!--    <h3>“My best days start here”</h3>-->
                                <!--<a class="video-play-button " href="">-->
                                <!--    <i class="flaticon-play-button "></i>-->
                                <!--    <span>Pay</span>-->
                                <!--</a>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <!-- Testimonial Item -->
                    <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/Asset 10.png" alt="">
                            <!--<div class="testimonial-text">-->
                            <!--    <h3>“Best place to burn fate and make best ftness”</h3>-->
                                <!--<a class="video-play-button " href="https://www.youtube.com/watch?v=ZoZSp-wy8h8">-->
                                <!--    <i class="flaticon-play-button "></i>-->
                                <!--    <span>Take a Tour</span>-->
                                <!--</a>-->
                            <!--</div>-->
                        </div>
                    </div>


                     <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/Asset 7.png" alt="">
                            <!--<div class="testimonial-text">-->
                            <!--    <h3>“My best days start here”</h3>-->
                                <!--<a class="video-play-button " href="">-->
                                <!--    <i class="flaticon-play-button "></i>-->
                                <!--    <span>Pay</span>-->
                                <!--</a>-->
                            <!--</div>-->
                        </div>
                    </div>
                    <!-- Testimonial Item -->
                    <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/Asset 8.png" alt="">
                            <!--<div class="testimonial-text">-->
                            <!--    <h3>“Best place to burn fate and make best ftness”</h3>-->
                                <!--<a class="video-play-button " href="https://www.youtube.com/watch?v=ZoZSp-wy8h8">-->
                                <!--    <i class="flaticon-play-button "></i>-->
                                <!--    <span>Take a Tour</span>-->
                                <!--</a>-->
                            <!--</div>-->
                        </div>
                    </div>



                </div>
            </div>


            </section>
            <br><br> <br><br>

             <!-- =====>> End Feature <<=====
    =========================== -->
        <section id="testimonial-area">
               <div class="container ">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 ">
                    <div class="section-title text-center ">
                        <h2>Referral Bonus</h2>
                           <p>Do you know that you stand a chance of winning a gift coupon worth #5000 to our exclusive recreational community, Just by registering 5 people?
<br>Get 5 people to join our fitness and lifestyle community and enjoy amazing services worth 5k!!! You don't want to miss out on this one o...

<br><br>
<b>Hurry! Get your own gift coupon Now!</b></p>
                    </div>
                </div>
            </div>
        </div>

     <div class="testimonial-content pt-40">



                    <!-- Testimonial Item -->
                    <div class="col-lg-12">
                        <div class="testimonial-item mt-40">
                            <img src="/Asset 9.png" alt="">
                            <!--<div class="testimonial-text">-->
                            <!--    <h3>“My best days start here”</h3>-->
                                <!--<a class="video-play-button " href="">-->
                                <!--    <i class="flaticon-play-button "></i>-->
                                <!--    <span>Pay</span>-->
                                <!--</a>-->
                            <!--</div>-->
                        </div>
                    </div>



            </div>


            </section>

        <br><br>

    <!-- ===========================
    =====>> Testimonial <<===== -->
    <section id="testimonial-area" class="testimonial-home1 pt-150">
        <div class="container">
            <div class="row ">
                <div class="col-lg-8">
                    <div class="section-title text-left">
                        <h2>Member Success <span>Stories</span></h2>
                        <p>Kick your feet up! With a gym designed around you, we think
                            <br> you’ll love it here.</p>
                    </div>
                </div>
            </div>
            <div class="testimonial-content pt-40">
                <div class="row">
                    <!-- Testimonial Item -->
                    <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/testimony1.png" alt="">
                            <div class="testimonial-text">
                                <h3>“I am Determined To Achieve my Fitness Goals at Greatlife Fitness & Lifestyle Centre”</h3>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=THsT2VeY_Sc">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Testimonial Item -->
                    <div class="col-lg-6">
                        <div class="testimonial-item mt-40">
                            <img src="/testimony2.png"height="355" alt="/testimony2.png">
                            <div class="testimonial-text">
                                <h3>“Best place to burn fat and stay fit”</h3>
                                <a class="video-play-button " href="https://www.youtube.com/watch?v=kBLK8Ri8egg">
                                    <i class="flaticon-play-button "></i>
                                    <span>Take a Tour</span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- =====>> End Testimonial <<=====
    =========================== -->







    @endsection
